
package contribuintes;

public class ContribuintePublico {
    
}
